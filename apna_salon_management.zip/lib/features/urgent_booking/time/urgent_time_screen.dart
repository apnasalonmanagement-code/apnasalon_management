import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../review/urgent_review_screen.dart';
import 'urgent_time_controller.dart';

class UrgentTimeScreen extends StatelessWidget {
  const UrgentTimeScreen({
    super.key,
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
    required this.selectedServices,
    required this.selectedStaff,
    required this.totalDuration,
    required this.totalPrice,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;
  final List<Map<String, dynamic>> selectedServices;
  final Map<String, dynamic> selectedStaff;
  final int totalDuration;
  final double totalPrice;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UrgentTimeController(
        shopId: shopId,
        staffId: selectedStaff['id'].toString(),
        bookingDate: bookingDate,
        durationMinutes: totalDuration,
      ),
      child: _UrgentTimeView(
        shopId: shopId,
        customerName: customerName,
          customerPhone: customerPhone,
        bookingDate: bookingDate,
        selectedServices: selectedServices,
        selectedStaff: selectedStaff,
        totalDuration: totalDuration,
        totalPrice: totalPrice,
      ),
    );
  }
}

class _UrgentTimeView extends StatelessWidget {
  const _UrgentTimeView({
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
    required this.selectedServices,
    required this.selectedStaff,
    required this.totalDuration,
    required this.totalPrice,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;
  final List<Map<String, dynamic>> selectedServices;
  final Map<String, dynamic> selectedStaff;
  final int totalDuration;
  final double totalPrice;

  void _continue(BuildContext context, UrgentTimeController controller) {
    final time = controller.selectedTime;
    if (time == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a time.')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UrgentReviewScreen(
          shopId: shopId,
          customerName: customerName,
          customerPhone: customerPhone,
          bookingDate: bookingDate,
          selectedServices: selectedServices,
          selectedStaff: selectedStaff,
          selectedTime: time,
          totalDuration: totalDuration,
          totalPrice: totalPrice,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Time')),
      body: Consumer<UrgentTimeController>(
        builder: (context, controller, _) {
          if (controller.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (controller.errorMessage != null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 44),
                    const SizedBox(height: 12),
                    Text(controller.errorMessage!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: controller.loadTimes, child: const Text('Try Again')),
                  ],
                ),
              ),
            );
          }

          if (controller.times.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No available starting times for this staff member on the selected date.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          return Column(
            children: [
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 180,
                    mainAxisExtent: 52,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: controller.times.length,
                  itemBuilder: (context, index) {
                    final time = controller.times[index];
                    final selected = controller.selectedTime == time;
                    return OutlinedButton(
                      onPressed: () => controller.selectTime(time),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: selected
                              ? Theme.of(context).colorScheme.primary
                              : Theme.of(context).dividerColor,
                          width: selected ? 2 : 1,
                        ),
                        backgroundColor: selected
                            ? Theme.of(context).colorScheme.primaryContainer
                            : null,
                      ),
                      child: Text(controller.displayTime(time)),
                    );
                  },
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: controller.selectedTime == null
                          ? null
                          : () => _continue(context, controller),
                      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                      child: const Text('REVIEW BOOKING'),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
