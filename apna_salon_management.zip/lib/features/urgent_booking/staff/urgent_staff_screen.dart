import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../time/urgent_time_screen.dart';
import 'urgent_staff_controller.dart';

class UrgentStaffScreen extends StatelessWidget {
  const UrgentStaffScreen({
    super.key,
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
    required this.selectedServices,
    required this.totalDuration,
    required this.totalPrice,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;
  final List<Map<String, dynamic>> selectedServices;
  final int totalDuration;
  final double totalPrice;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UrgentStaffController(shopId: shopId),
      child: _UrgentStaffView(
        shopId: shopId,
        customerName: customerName,
          customerPhone: customerPhone,
        bookingDate: bookingDate,
        selectedServices: selectedServices,
        totalDuration: totalDuration,
        totalPrice: totalPrice,
      ),
    );
  }
}

class _UrgentStaffView extends StatelessWidget {
  const _UrgentStaffView({
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
    required this.selectedServices,
    required this.totalDuration,
    required this.totalPrice,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;
  final List<Map<String, dynamic>> selectedServices;
  final int totalDuration;
  final double totalPrice;

  void _continue(BuildContext context, UrgentStaffController controller) {
    final staff = controller.selectedStaff;
    if (staff == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a staff member.')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UrgentTimeScreen(
          shopId: shopId,
          customerName: customerName,
          customerPhone: customerPhone,
          bookingDate: bookingDate,
          selectedServices: selectedServices,
          selectedStaff: staff,
          totalDuration: totalDuration,
          totalPrice: totalPrice,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Staff')),
      body: Consumer<UrgentStaffController>(
        builder: (context, controller, _) {
          if (controller.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (controller.errorMessage != null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(controller.errorMessage!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: controller.loadStaff, child: const Text('Try Again')),
                  ],
                ),
              ),
            );
          }

          if (controller.staff.isEmpty) {
            return const Center(child: Text('No active staff members found for this shop.'));
          }

          return Column(
            children: [
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.staff.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final staff = controller.staff[index];
                    final id = staff['id'].toString();
                    final selected = controller.selectedStaffId == id;
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(12),
                        leading: CircleAvatar(
                          child: Text(
                            (staff['name']?.toString().isNotEmpty == true)
                                ? staff['name'].toString().substring(0, 1).toUpperCase()
                                : '?',
                          ),
                        ),
                        title: Text(staff['name']?.toString() ?? 'Staff'),
                        subtitle: Text(
                          [
                            staff['role']?.toString() ?? '',
                            staff['phone']?.toString() ?? '',
                          ].where((v) => v.isNotEmpty).join(' • '),
                        ),
                        trailing: Icon(
                          selected ? Icons.radio_button_checked : Icons.radio_button_off,
                          color: selected ? Theme.of(context).colorScheme.primary : null,
                        ),
                        onTap: () => controller.selectStaff(id),
                      ),
                    );
                  },
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: controller.selectedStaffId == null
                          ? null
                          : () => _continue(context, controller),
                      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                      child: const Text('CONTINUE'),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
