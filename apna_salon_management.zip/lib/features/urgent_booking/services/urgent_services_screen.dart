import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../staff/urgent_staff_screen.dart';
import 'urgent_services_controller.dart';

class UrgentServicesScreen extends StatelessWidget {
  const UrgentServicesScreen({
    super.key,
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UrgentServicesController(shopId: shopId),
      child: _UrgentServicesView(
        shopId: shopId,
        customerName: customerName,
          customerPhone: customerPhone,
        bookingDate: bookingDate,
      ),
    );
  }
}

class _UrgentServicesView extends StatelessWidget {
  const _UrgentServicesView({
    required this.shopId,
    required this.customerName,
    required this.customerPhone,
    required this.bookingDate,
  });

  final String shopId;
  final String customerName;
  final String customerPhone;
  final DateTime bookingDate;

  void _continue(BuildContext context, UrgentServicesController controller) {
    if (controller.selectedIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one service.')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UrgentStaffScreen(
          shopId: shopId,
          customerName: customerName,
          customerPhone: customerPhone,
          bookingDate: bookingDate,
          selectedServices: controller.selectedServices,
          totalDuration: controller.totalDuration,
          totalPrice: controller.totalPrice,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Services')),
      body: Consumer<UrgentServicesController>(
        builder: (context, controller, _) {
          if (controller.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (controller.errorMessage != null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(controller.errorMessage!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: controller.loadServices,
                      child: const Text('Try Again'),
                    ),
                  ],
                ),
              ),
            );
          }

          if (controller.services.isEmpty) {
            return const Center(child: Text('No active services found for this shop.'));
          }

          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
                  children: [
                    Text(
                      'Select one or more services',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    for (final category in controller.categories) ...[
                      Padding(
                        padding: const EdgeInsets.only(top: 12, bottom: 8),
                        child: Text(
                          category,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      ...controller.servicesForCategory(category).map(
                        (service) => _ServiceTile(
                          service: service,
                          selected: controller.isSelected(service['id'].toString()),
                          onTap: () => controller.toggleService(service['id'].toString()),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              _BottomSummary(
                duration: controller.totalDuration,
                price: controller.totalPrice,
                enabled: controller.selectedIds.isNotEmpty,
                onContinue: () => _continue(context, controller),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({required this.service, required this.selected, required this.onTap});

  final Map<String, dynamic> service;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final duration = service['duration_minutes']?.toString() ?? '0';
    final price = _price(service['price']);

    return Card(
      child: CheckboxListTile(
        value: selected,
        onChanged: (_) => onTap(),
        title: Text(service['service_name']?.toString() ?? 'Service'),
        subtitle: Text('$duration min  •  ₹$price'),
        secondary: service['request'] == true
            ? const Tooltip(
                message: 'This service normally requires a request',
                child: Icon(Icons.info_outline),
              )
            : null,
      ),
    );
  }

  String _price(dynamic value) {
    if (value is num) return value.toStringAsFixed(0);
    return double.tryParse(value?.toString() ?? '')?.toStringAsFixed(0) ?? '0';
  }
}

class _BottomSummary extends StatelessWidget {
  const _BottomSummary({required this.duration, required this.price, required this.enabled, required this.onContinue});

  final int duration;
  final double price;
  final bool enabled;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 10,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$duration min', style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('₹${price.toStringAsFixed(0)}'),
                  ],
                ),
              ),
              FilledButton(onPressed: enabled ? onContinue : null, child: const Text('CONTINUE')),
            ],
          ),
        ),
      ),
    );
  }
}
