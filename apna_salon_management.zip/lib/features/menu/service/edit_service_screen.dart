import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../models/service_model.dart';
import 'service_controller.dart';

class EditServiceScreen extends StatefulWidget {
  const EditServiceScreen({
    super.key,
    required this.service,
  });

  final ServiceModel service;

  @override
  State<EditServiceScreen> createState() => _EditServiceScreenState();
}

class _EditServiceScreenState extends State<EditServiceScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _categoryController;
  late final TextEditingController _serviceController;
  late final TextEditingController _durationController;
  late final TextEditingController _priceController;
  late final ServiceController _controller;

  bool _request = false;
  bool _status = true;
  bool _saving = false;
  bool _replaceImage = false;
  XFile? _selectedImage;
  String? _imageUrl;

  @override
  void initState() {
    super.initState();
    final service = widget.service;

    _controller = ServiceController();
    _categoryController = TextEditingController(text: service.categoryName);
    _serviceController = TextEditingController(text: service.serviceName);
    _durationController = TextEditingController(
      text: service.durationMinutes.toString(),
    );
    _priceController = TextEditingController(
      text: service.price.toStringAsFixed(2),
    );

    _request = service.request;
    _status = service.status;
    _imageUrl = service.imageUrl;
  }

  @override
  void dispose() {
    _categoryController.dispose();
    _serviceController.dispose();
    _durationController.dispose();
    _priceController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );

    if (file == null || !mounted) return;

    setState(() {
      _selectedImage = file;
      _replaceImage = true;
    });

    final url = await _controller.uploadImage(file);
    if (!mounted) return;

    if (url != null) {
      setState(() => _imageUrl = url);
    } else if (_controller.errorMessage != null) {
      _showMessage(_controller.errorMessage!);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final duration = int.tryParse(_durationController.text.trim());
    final price = double.tryParse(_priceController.text.trim());

    if (duration == null || duration <= 0 || duration % 15 != 0) {
      _showMessage('Duration must be greater than 0 and a multiple of 15 minutes.');
      return;
    }
    if (price == null || price < 0) return;

    setState(() => _saving = true);

    final result = await _controller.update(
      serviceId: widget.service.id,
      categoryName: _categoryController.text,
      serviceName: _serviceController.text,
      durationMinutes: duration,
      price: price,
      request: _request,
      status: _status,
      imageUrl: _imageUrl,
      replaceImageUrl: _replaceImage,
    );

    if (!mounted) return;

    setState(() => _saving = false);

    if (result != null) {
      Navigator.pop(context, result);
    } else {
      _showMessage(
        _controller.errorMessage ?? 'Unable to update service.',
      );
    }
  }

  Future<void> _deactivate() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Deactivate Service?'),
        content: Text(
          '"${widget.service.serviceName}" will no longer be available for new bookings. Existing appointments will not be changed.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('KEEP'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('DEACTIVATE'),
          ),
        ],
      ),
    );

    if (confirm != true || !mounted) return;

    setState(() => _saving = true);
    final success = await _controller.deactivate(widget.service.id);

    if (!mounted) return;

    setState(() => _saving = false);

    if (success) {
      Navigator.pop(context, null);
    } else {
      _showMessage(
        _controller.errorMessage ?? 'Unable to deactivate service.',
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  String? _required(String? value, String label) {
    if (value == null || value.trim().isEmpty) {
      return '$label is required.';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Edit Service'),
            actions: [
              IconButton(
                tooltip: 'Deactivate',
                onPressed: _saving ? null : _deactivate,
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
          body: SafeArea(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  _CurrentImageCard(
                    imageUrl: _imageUrl,
                    selectedImage: _selectedImage,
                    uploading: _controller.isUploadingImage,
                    onPick: _pickImage,
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _categoryController,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Category Name',
                      prefixIcon: Icon(Icons.category_outlined),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => _required(value, 'Category'),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _serviceController,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Service Name',
                      prefixIcon: Icon(Icons.content_cut_outlined),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => _required(value, 'Service name'),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _durationController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Duration (minutes)',
                      prefixIcon: Icon(Icons.schedule_outlined),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final duration = int.tryParse(value?.trim() ?? '');
                      if (duration == null || duration <= 0) {
                        return 'Duration must be greater than 0.';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _priceController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Price',
                      prefixIcon: Icon(Icons.currency_rupee),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final price = double.tryParse(value?.trim() ?? '');
                      if (price == null || price < 0) {
                        return 'Price must be 0 or greater.';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 8),
                  _RequestSwitch(
                    value: _request,
                    enabled: !_saving,
                    onChanged: (value) => setState(() => _request = value),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: SwitchListTile(
                      title: Text(
                        _status ? 'Service Active' : 'Service Inactive',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: const Text(
                        'Inactive services are hidden from new bookings.',
                      ),
                      value: _status,
                      onChanged: _saving
                          ? null
                          : (value) => setState(() => _status = value),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    height: 52,
                    child: FilledButton(
                      onPressed: _saving || _controller.isUploadingImage ? null : _save,
                      child: _saving
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('SAVE CHANGES'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _RequestSwitch extends StatelessWidget {
  const _RequestSwitch({
    required this.value,
    required this.enabled,
    required this.onChanged,
  });

  final bool value;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SwitchListTile(
        title: Text(
          value ? 'Send Request ON' : 'Send Request OFF',
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          value
              ? 'Bookings using this service require management approval.'
              : 'Bookings using this service can be directly confirmed.',
        ),
        value: value,
        onChanged: enabled ? onChanged : null,
      ),
    );
  }
}

class _CurrentImageCard extends StatelessWidget {
  const _CurrentImageCard({
    required this.imageUrl,
    required this.selectedImage,
    required this.uploading,
    required this.onPick,
  });

  final String? imageUrl;
  final XFile? selectedImage;
  final bool uploading;
  final VoidCallback onPick;

  @override
  Widget build(BuildContext context) {
    final provider = imageUrl != null && imageUrl!.isNotEmpty
        ? NetworkImage(imageUrl!)
        : null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 38,
              backgroundImage: provider,
              child: provider == null
                  ? const Icon(Icons.image_outlined, size: 32)
                  : null,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Service Image',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(selectedImage?.name ?? 'Current image / optional'),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: uploading ? null : onPick,
                    icon: uploading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.upload_outlined),
                    label: Text(uploading ? 'Uploading...' : 'Change Image'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
