import 'package:flutter/material.dart';

import 'package:apna_salon_management/features/staff/staff_controller.dart';
import 'package:apna_salon_management/features/staff/add_staff_screen.dart';
import 'package:apna_salon_management/features/staff/edit_staff_screen.dart';

class StaffManagementScreen extends StatefulWidget {
  const StaffManagementScreen({super.key});

  @override
  State<StaffManagementScreen> createState() => _StaffManagementScreenState();
}

class _StaffManagementScreenState extends State<StaffManagementScreen> {
  late final StaffController controller;

  @override
  void initState() {
    super.initState();
    controller = StaffController()..addListener(_refresh)..load();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    controller.removeListener(_refresh);
    controller.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddStaffScreen()),
    );
    await controller.load();
  }

  Future<void> _edit(Map<String, dynamic> staff) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditStaffScreen(initial: staff)),
    );
    await controller.load();
  }

  Future<void> _toggle(Map<String, dynamic> item) async {
    final current = item['status'] == true;
    final name = item['name']?.toString() ?? 'staff member';
    final action = current ? 'deactivate' : 'activate';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${current ? 'Deactivate' : 'Activate'} staff?'),
        content: Text('Do you want to $action $name?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(current ? 'Deactivate' : 'Activate')),
        ],
      ),
    );
    if (confirmed != true) return;

    final ok = await controller.setStatus(item['id'].toString(), !current);
    if (!ok && mounted) _message(controller.errorMessage ?? 'Unable to update staff status.');
  }

  Future<void> _delete(Map<String, dynamic> item) async {
    final name = item['name']?.toString() ?? 'this staff member';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete staff?'),
        content: Text('Delete $name permanently? This is allowed only when there are no appointments linked to this staff member.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed != true) return;

    final ok = await controller.delete(item['id'].toString());
    if (!ok && mounted) _message(controller.errorMessage ?? 'Unable to delete staff.');
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Staff Management'),
        actions: [IconButton(onPressed: controller.isLoading ? null : controller.load, icon: const Icon(Icons.refresh))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Add Staff'),
      ),
      body: controller.isLoading && controller.staff.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : controller.staff.isEmpty
              ? _empty()
              : RefreshIndicator(
                  onRefresh: controller.load,
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    itemCount: controller.staff.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, index) => _card(controller.staff[index]),
                  ),
                ),
    );
  }

  Widget _empty() => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.groups_outlined, size: 64),
              const SizedBox(height: 12),
              const Text('No staff members yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text(controller.errorMessage ?? 'Add your first staff member to start managing staff.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(onPressed: _add, icon: const Icon(Icons.person_add), label: const Text('Add Staff')),
            ],
          ),
        ),
      );

  Widget _card(Map<String, dynamic> item) {
    final active = item['status'] == true;
    final image = item['image_url']?.toString() ?? '';
    final name = item['name']?.toString() ?? 'Unnamed';
    final phone = item['phone']?.toString() ?? '';
    final role = item['role']?.toString() ?? '';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundImage: image.isNotEmpty ? NetworkImage(image) : null,
              child: image.isEmpty ? const Icon(Icons.person, size: 30) : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                  if (role.isNotEmpty) Text(role),
                  if (phone.isNotEmpty) Text(phone),
                  const SizedBox(height: 5),
                  Chip(
                    label: Text(active ? 'Active' : 'Inactive'),
                    visualDensity: VisualDensity.compact,
                  ),
                ],
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') _edit(item);
                if (value == 'toggle') _toggle(item);
                if (value == 'delete') _delete(item);
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'edit', child: Text('Edit')),
                PopupMenuItem(value: 'toggle', child: Text(active ? 'Deactivate' : 'Activate')),
                const PopupMenuItem(value: 'delete', child: Text('Delete')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
