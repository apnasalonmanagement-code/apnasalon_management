import 'package:flutter/material.dart';

class AppTheme {
  AppTheme._();

  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.black,
    ),
    scaffoldBackgroundColor: Colors.white,
    inputDecorationTheme:
        const InputDecorationTheme(
      border: OutlineInputBorder(),
    ),
  );
}