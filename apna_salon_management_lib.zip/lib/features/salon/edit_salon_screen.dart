import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/services/cloudinary_service.dart';
import 'salon_controller.dart';

class EditSalonScreen extends StatefulWidget {
  const EditSalonScreen({super.key, required this.initial});
  final Map<String, dynamic> initial;
  @override State<EditSalonScreen> createState() => _EditSalonScreenState();
}
class _EditSalonScreenState extends State<EditSalonScreen> {
  late final TextEditingController name, city, phone, location, description, image;
  TimeOfDay? opening, closing;
  bool status = true, uploading = false;
  final CloudinaryService cloudinary = const CloudinaryService();
  final SalonController controller = SalonController();
  @override void initState() { super.initState(); final s=widget.initial; name=TextEditingController(text:s['shop_name']?.toString()??''); city=TextEditingController(text:s['city']?.toString()??''); phone=TextEditingController(text:s['phone']?.toString()??''); location=TextEditingController(text:s['location_url']?.toString()??''); description=TextEditingController(text:s['description']?.toString()??''); image=TextEditingController(text:s['image_url']?.toString()??''); status=s['status'] as bool? ?? true; opening=_parse(s['opening_time']); closing=_parse(s['closing_time']); }
  @override void dispose(){ for(final c in [name,city,phone,location,description,image]) c.dispose(); controller.dispose(); super.dispose(); }
  TimeOfDay? _parse(dynamic v){ if(v==null) return null; final p=v.toString().split(':'); if(p.length<2)return null; return TimeOfDay(hour:int.tryParse(p[0])??0,minute:int.tryParse(p[1])??0); }
  String _time(TimeOfDay? t)=>t==null?'': '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}:00';
  Future<void> _pickImage() async { final file=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:85); if(file==null)return; if(!cloudinary.isConfigured){ ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Cloudinary is not configured. You can enter an image URL manually.'))); return; } setState(()=>uploading=true); try { final url=await cloudinary.uploadShopImage(file); if(url!=null) image.text=url; } catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ','')))); } finally { if(mounted)setState(()=>uploading=false); } }
  Future<void> _timePicker(bool isOpening) async { final picked=await showTimePicker(context:context,initialTime:(isOpening?opening:closing)??TimeOfDay.now()); if(picked!=null)setState(()=>isOpening?opening=picked:closing=picked); }
  Future<void> _save() async { if(name.text.trim().isEmpty||city.text.trim().isEmpty){_msg('Shop name and city are required.');return;} if(opening!=null&&closing!=null&&_minutes(closing!)<=_minutes(opening!)){_msg('Closing time must be after opening time.');return;} final ok=await controller.save({'shop_name':name.text.trim(),'city':city.text.trim(),'phone':phone.text.trim().isEmpty?null:phone.text.trim(),'location_url':location.text.trim().isEmpty?null:location.text.trim(),'description':description.text.trim().isEmpty?null:description.text.trim(),'image_url':image.text.trim().isEmpty?null:image.text.trim(),'opening_time':opening==null?null:_time(opening),'closing_time':closing==null?null:_time(closing),'status':status,'updated_at':DateTime.now().toUtc().toIso8601String()}); if(ok&&mounted)Navigator.pop(context,true); else if(controller.errorMessage!=null)_msg(controller.errorMessage!); }
  int _minutes(TimeOfDay t)=>t.hour*60+t.minute; void _msg(String m)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m)));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Edit Shop')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Shop name')),TextField(controller:city,decoration:const InputDecoration(labelText:'City')),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Phone')),TextField(controller:location,decoration:const InputDecoration(labelText:'Location URL')),TextField(controller:description,maxLines:3,decoration:const InputDecoration(labelText:'Description')),const SizedBox(height:12),Row(children:[Expanded(child:TextField(controller:image,decoration:const InputDecoration(labelText:'Image URL'))),IconButton(onPressed:uploading?null:_pickImage,icon:uploading?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.cloud_upload_outlined))]),ListTile(title:const Text('Opening time'),subtitle:Text(opening?.format(context)??'Not set'),onTap:()=>_timePicker(true)),ListTile(title:const Text('Closing time'),subtitle:Text(closing?.format(context)??'Not set'),onTap:()=>_timePicker(false)),SwitchListTile(title:const Text('Shop active'),value:status,onChanged:(v)=>setState(()=>status=v)),const SizedBox(height:12),FilledButton(onPressed:controller.isSaving?null:_save,child:controller.isSaving?const CircularProgressIndicator():const Text('Save changes'))]));
}
