import 'package:flutter/material.dart';

import '../../models/availability_model.dart';
import 'availability_controller.dart';
import 'widgets/calendar_widget.dart';
import 'widgets/staff_availability_item.dart';
import 'widgets/time_range_selector.dart';

class AvailabilityCalendarScreen extends StatefulWidget {
  const AvailabilityCalendarScreen({super.key});

  @override
  State<AvailabilityCalendarScreen> createState() =>
      _AvailabilityCalendarScreenState();
}

class _AvailabilityCalendarScreenState extends State<AvailabilityCalendarScreen> {
  late final AvailabilityController _controller;
  String _view = 'all';

  @override
  void initState() {
    super.initState();
    _controller = AvailabilityController();
    _controller.addListener(_refresh);
    _controller.initialize();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller.removeListener(_refresh);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final shop = _controller.shopRecords;
    final staff = _controller.staffRecords;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Availability'),
        actions: [
          IconButton(
            tooltip: 'Weekly configuration',
            icon: const Icon(Icons.repeat),
            onPressed: _openWeeklyConfiguration,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('Add'),
      ),
      body: _controller.isLoading && _controller.records.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => _controller.loadForDate(_controller.selectedDate),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                children: [
                  AvailabilityCalendar(
                    selectedDate: _controller.selectedDate,
                    onDateSelected: _controller.loadForDate,
                  ),
                  if (_controller.errorMessage != null) ...[
                    const SizedBox(height: 10),
                    _errorCard(_controller.errorMessage!),
                  ],
                  const SizedBox(height: 14),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'all', label: Text('All'), icon: Icon(Icons.view_agenda_outlined)),
                      ButtonSegment(value: 'shop', label: Text('Shop'), icon: Icon(Icons.store_outlined)),
                      ButtonSegment(value: 'staff', label: Text('Staff'), icon: Icon(Icons.people_outline)),
                    ],
                    selected: {_view},
                    onSelectionChanged: (value) => setState(() => _view = value.first),
                  ),
                  const SizedBox(height: 16),
                  if (_view != 'staff') _shopSection(shop),
                  if (_view == 'all') const SizedBox(height: 12),
                  if (_view != 'shop') _staffSection(staff),
                ],
              ),
            ),
    );
  }

  Widget _shopSection(List<AvailabilityModel> records) {
    final active = records.where((e) => e.status).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('Shop Availability', Icons.store_outlined),
        if (active.isEmpty)
          const _Empty(text: 'No shop availability configured for this date.')
        else
          ...records.map((r) => _recordCard(r)),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => _openEditor(),
          icon: const Icon(Icons.add_business_outlined),
          label: const Text('Add shop working window / holiday'),
        ),
      ],
    );
  }

  Widget _staffSection(List<AvailabilityModel> records) {
    final byStaff = <String, List<AvailabilityModel>>{};
    for (final record in records) {
      byStaff.putIfAbsent(record.staffId!, () => []).add(record);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('Staff Availability', Icons.people_outline),
        if (_controller.staff.isEmpty)
          const _Empty(text: 'No active staff found for this shop.')
        else
          ..._controller.staff.map((person) {
            final id = person['id'].toString();
            return StaffAvailabilityItem(
              staffName: person['name']?.toString() ?? 'Staff',
              records: byStaff[id] ?? const [],
              onEdit: (record) => _openEditor(
  record: record,
),
              onToggle: (record) => _toggle(record),
            );
          }),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => _openEditor(defaultStaffId: _controller.staff.isEmpty ? null : _controller.staff.first['id'].toString()),
          icon: const Icon(Icons.person_add_alt_1_outlined),
          label: const Text('Add staff availability'),
        ),
      ],
    );
  }

  Widget _recordCard(AvailabilityModel record) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(_icon(record.type))),
        title: Text(_recordTitle(record)),
        subtitle: Text(
          '${record.startTime ?? 'All day'}${record.endTime == null ? '' : ' → ${record.endTime}'}${record.reason == null ? '' : '\n${record.reason}'}',
        ),
        trailing: Wrap(
          spacing: 0,
          children: [
            Switch(value: record.status, onChanged: (_) => _toggle(record)),
            IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _openEditor(record: record)),
          ],
        ),
      ),
    );
  }

  Future<void> _toggle(AvailabilityModel record) async {
    final ok = await _controller.setStatus(record.id, !record.status);
    if (!ok && mounted) _showError(_controller.errorMessage);
  }

  Future<void> _openEditor({AvailabilityModel? record, String? defaultStaffId}) async {
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _AvailabilityEditor(
        controller: _controller,
        record: record,
        selectedDate: _controller.selectedDate,
        defaultStaffId: defaultStaffId,
      ),
    );
    if (changed == true) await _controller.loadForDate(_controller.selectedDate);
  }

  Future<void> _openWeeklyConfiguration() async {
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _WeeklyEditor(controller: _controller),
    );
    if (changed == true) await _controller.loadForDate(_controller.selectedDate);
  }

  Widget _sectionTitle(String title, IconData icon) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [Icon(icon, size: 21), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))]),
      );

  Widget _errorCard(String text) => Card(color: Theme.of(context).colorScheme.errorContainer, child: Padding(padding: const EdgeInsets.all(12), child: Text(text)));

  String _recordTitle(AvailabilityModel record) {
    final title = record.type[0].toUpperCase() + record.type.substring(1);
    return record.status ? title : '$title • Inactive';
  }

  IconData _icon(String type) {
    switch (type) {
      case 'break': return Icons.free_breakfast_outlined;
      case 'leave': return Icons.event_busy_outlined;
      case 'holiday': return Icons.beach_access_outlined;
      default: return Icons.work_outline;
    }
  }

  void _showError(String? message) {
    if (message == null || message.isEmpty) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _AvailabilityEditor extends StatefulWidget {
  const _AvailabilityEditor({required this.controller, required this.selectedDate, this.record, this.defaultStaffId});
  final AvailabilityController controller;
  final DateTime selectedDate;
  final AvailabilityModel? record;
  final String? defaultStaffId;
  @override State<_AvailabilityEditor> createState() => _AvailabilityEditorState();
}

class _AvailabilityEditorState extends State<_AvailabilityEditor> {
  late String _type;
  late String? _staffId;
  late bool _dateSpecific;
  late bool _status;
  late TextEditingController _reason;
  TimeOfDay? _start;
  TimeOfDay? _end;
  DateTime? _date;
  int? _day;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final r = widget.record;
    _type = r?.type ?? 'working';
    _staffId = r?.staffId ?? widget.defaultStaffId;
    _dateSpecific = r?.date != null || r == null;
    _status = r?.status ?? true;
    _reason = TextEditingController(text: r?.reason ?? '');
    _date = r?.date ?? widget.selectedDate;
    _day = r?.dayOfWeek ?? (widget.selectedDate.weekday % 7);
    _start = _parseTime(r?.startTime);
    _end = _parseTime(r?.endTime);
  }

  @override
  void dispose() { _reason.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final holiday = _type == 'holiday';
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.record == null ? 'Add Availability' : 'Edit Availability', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _type,
            decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'working', child: Text('Working window')),
              DropdownMenuItem(value: 'break', child: Text('Break')),
              DropdownMenuItem(value: 'leave', child: Text('Leave')),
              DropdownMenuItem(value: 'holiday', child: Text('Shop holiday')),
            ],
            onChanged: (v) => setState(() => _type = v ?? 'working'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _staffId,
            decoration: const InputDecoration(labelText: 'Staff', border: OutlineInputBorder(), helperText: 'Leave empty for shop-level availability'),
            items: [
              const DropdownMenuItem<String?>(value: null, child: Text('Shop / all staff')),
              ...widget.controller.staff.map((s) => DropdownMenuItem<String?>(value: s['id'].toString(), child: Text(s['name']?.toString() ?? 'Staff'))),
            ],
            onChanged: (v) => setState(() => _staffId = v),
          ),
          if (_type == 'holiday' && _staffId != null)
            const Padding(padding: EdgeInsets.only(top: 8), child: Text('A shop holiday must apply to the whole shop.', style: TextStyle(fontSize: 12))),
          const SizedBox(height: 12),
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: true, label: Text('Specific date')), ButtonSegment(value: false, label: Text('Weekly'))],
            selected: {_dateSpecific},
            onSelectionChanged: widget.record == null ? (v) => setState(() => _dateSpecific = v.first) : null,
          ),
          const SizedBox(height: 12),
          if (_dateSpecific)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Date: ${_date!.day}/${_date!.month}/${_date!.year}'),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final d = await showDatePicker(context: context, initialDate: _date!, firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime.now().add(const Duration(days: 365 * 2)));
                if (d != null) setState(() => _date = d);
              },
            )
          else
            DropdownButtonFormField<int>(
              value: _day,
              decoration: const InputDecoration(labelText: 'Weekly day', border: OutlineInputBorder()),
              items: const [0,1,2,3,4,5,6].map((d) => DropdownMenuItem(value: d, child: Text(_days[d]))).toList(),
              onChanged: (v) => setState(() => _day = v),
            ),
          if (!holiday) ...[
            const SizedBox(height: 12),
            TimeRangeSelector(start: _start, end: _end, onStartChanged: (v) => setState(() => _start = v), onEndChanged: (v) => setState(() => _end = v)),
          ],
          const SizedBox(height: 12),
          TextField(controller: _reason, maxLines: 2, decoration: InputDecoration(labelText: holiday ? 'Holiday reason' : 'Note / reason (optional)', border: const OutlineInputBorder())),
          const SizedBox(height: 10),
          SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Active'), value: _status, onChanged: (v) => setState(() => _status = v)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _saving ? null : _save, icon: _saving ? const SizedBox(width: 18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.save), label: Text(_saving ? 'Saving...' : 'Save'))),
        ]),
      ),
    );
  }

  Future<void> _save() async {
    if (_type == 'holiday' && _staffId != null) { _error('A shop holiday cannot be assigned to one staff member.'); return; }
    if (_type != 'holiday' && (_start == null || _end == null)) { _error('Select both start and end time.'); return; }
    if (_type != 'holiday' && _start != null && _end != null && _toMinutes(_start!) >= _toMinutes(_end!)) { _error('End time must be after start time.'); return; }
    setState(() => _saving = true);
    final ok = await widget.controller.save(
      id: widget.record?.id,
      staffId: _staffId,
      date: _dateSpecific ? _date : null,
      dayOfWeek: _dateSpecific ? null : _day,
      type: _type,
      startTime: _time(_start),
      endTime: _time(_end),
      reason: _reason.text,
      status: _status,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok) Navigator.pop(context, true); else _error(widget.controller.errorMessage ?? 'Unable to save availability.');
  }

  void _error(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  int _toMinutes(TimeOfDay t) => t.hour * 60 + t.minute;
  String? _time(TimeOfDay? t) => t == null ? null : '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}:00';
  TimeOfDay? _parseTime(String? value) { if (value == null || value.length < 5) return null; final p=value.substring(0,5).split(':'); return TimeOfDay(hour:int.parse(p[0]),minute:int.parse(p[1])); }
}

const _days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

class _WeeklyEditor extends StatefulWidget {
  const _WeeklyEditor({required this.controller});
  final AvailabilityController controller;
  @override State<_WeeklyEditor> createState() => _WeeklyEditorState();
}

class _WeeklyEditorState extends State<_WeeklyEditor> {
  int _day = DateTime.now().weekday % 7;
  String? _staffId;
  TimeOfDay? _start;
  TimeOfDay? _end;
  bool _saving = false;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20,12,20,20),
    child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Weekly Working Configuration', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 8),
      const Text('Create recurring working windows using day_of_week. Use date-specific records for overrides.'),
      const SizedBox(height: 16),
      DropdownButtonFormField<int>(value:_day, decoration:const InputDecoration(labelText:'Day of week',border:OutlineInputBorder()), items:const [0,1,2,3,4,5,6].map((d)=>DropdownMenuItem(value:d,child:Text(_days[d]))).toList(), onChanged:(v)=>setState(()=>_day=v??0)),
      const SizedBox(height:12),
      DropdownButtonFormField<String?>(value:_staffId, decoration:const InputDecoration(labelText:'Staff',border:OutlineInputBorder(),helperText:'Empty = shop weekly hours'), items:[const DropdownMenuItem<String?>(value:null,child:Text('Shop / all staff')), ...widget.controller.staff.map((s)=>DropdownMenuItem<String?>(value:s['id'].toString(),child:Text(s['name']?.toString()??'Staff')))], onChanged:(v)=>setState(()=>_staffId=v)),
      const SizedBox(height:12),
      TimeRangeSelector(start:_start,end:_end,onStartChanged:(v)=>setState(()=>_start=v),onEndChanged:(v)=>setState(()=>_end=v)),
      const SizedBox(height:16),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:_saving?null:_save,child:Text(_saving?'Saving...':'Add Weekly Window'))),
    ])),
  );

  Future<void> _save() async {
    if (_start == null || _end == null) { _error('Select both start and end time.'); return; }
    if (_minutes(_start!) >= _minutes(_end!)) { _error('End time must be after start time.'); return; }
    setState(()=>_saving=true);
    final ok=await widget.controller.save(staffId:_staffId,dayOfWeek:_day,type:'working',startTime:_time(_start),endTime:_time(_end));
    if(!mounted)return;
    setState(()=>_saving=false);
    if(ok) Navigator.pop(context,true); else _error(widget.controller.errorMessage??'Unable to save.');
  }
  void _error(String t)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t)));
  int _minutes(TimeOfDay t)=>t.hour*60+t.minute;
  String _time(TimeOfDay? t)=>'${t!.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}:00';
}

class _Empty extends StatelessWidget { const _Empty({required this.text}); final String text; @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(text))); }
