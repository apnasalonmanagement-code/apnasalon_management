import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'requests_controller.dart';
import 'widgets/request_card.dart';

class RequestsScreen extends StatelessWidget {
  const RequestsScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) =>
          RequestsController()..initialize(),
      child: const _RequestsView(),
    );
  }
}

class _RequestsView
    extends StatelessWidget {
  const _RequestsView();

  // ============================================================
  // CONFIRM DIALOG
  // ============================================================

  Future<void> _confirmRequest(
    BuildContext context,
    RequestsController controller,
    String appointmentId,
  ) async {
    final shouldConfirm =
        await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Confirm Request',
          ),
          content: const Text(
            'Are you sure you want to confirm this booking request?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child:
                  const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child:
                  const Text('Confirm'),
            ),
          ],
        );
      },
    );

    if (shouldConfirm != true) {
      return;
    }

    final success =
        await controller.confirmRequest(
      appointmentId,
    );

    if (!context.mounted) {
      return;
    }

    if (!success) {
      _showError(
        context,
        controller.errorMessage ??
            'Unable to confirm request.',
      );
    }
  }

  // ============================================================
  // REJECT DIALOG
  // ============================================================

  Future<void> _rejectRequest(
    BuildContext context,
    RequestsController controller,
    String appointmentId,
  ) async {
    final shouldReject =
        await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Reject Request',
          ),
          content: const Text(
            'Are you sure you want to reject this booking request?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child:
                  const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child:
                  const Text('Reject'),
            ),
          ],
        );
      },
    );

    if (shouldReject != true) {
      return;
    }

    final success =
        await controller.rejectRequest(
      appointmentId,
    );

    if (!context.mounted) {
      return;
    }

    if (!success) {
      _showError(
        context,
        controller.errorMessage ??
            'Unable to reject request.',
      );
    }
  }

  // ============================================================
  // ERROR
  // ============================================================

  void _showError(
    BuildContext context,
    String message,
  ) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  // ============================================================
  // REFRESH
  // ============================================================

  Future<void> _refresh(
    RequestsController controller,
  ) async {
    await controller.loadRequests();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Consumer<RequestsController>(
      builder: (
        context,
        controller,
        _,
      ) {
        return Scaffold(
          appBar: AppBar(
            title: const Text(
              'Requests',
            ),
            actions: [
              IconButton(
                tooltip: 'Refresh',
                onPressed:
                    controller.isLoading
                        ? null
                        : () =>
                            controller
                                .loadRequests(),
                icon:
                    const Icon(
                  Icons.refresh,
                ),
              ),
            ],
          ),

          body: _buildBody(
            context,
            controller,
          ),
        );
      },
    );
  }

  Widget _buildBody(
    BuildContext context,
    RequestsController controller,
  ) {
    if (controller.isLoading &&
        controller.requests.isEmpty) {
      return const Center(
        child:
            CircularProgressIndicator(),
      );
    }

    if (controller.errorMessage !=
            null &&
        controller.requests.isEmpty) {
      return Center(
        child: Padding(
          padding:
              const EdgeInsets.all(24),
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 52,
              ),

              const SizedBox(height: 14),

              Text(
                controller.errorMessage!,
                textAlign:
                    TextAlign.center,
              ),

              const SizedBox(height: 16),

              FilledButton(
                onPressed:
                    () => controller
                        .loadRequests(),
                child:
                    const Text(
                  'Try Again',
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (controller.requests.isEmpty) {
      return RefreshIndicator(
        onRefresh: () =>
            _refresh(controller),
        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 140),

            Icon(
              Icons.inbox_outlined,
              size: 70,
            ),

            SizedBox(height: 20),

            Center(
              child: Text(
                'No pending requests',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
            ),

            SizedBox(height: 8),

            Center(
              child: Text(
                'New booking requests will appear here.',
                textAlign:
                    TextAlign.center,
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () =>
          _refresh(controller),
      child: ListView.builder(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.all(16),
        itemCount:
            controller.requests.length,
        itemBuilder:
            (context, index) {
          final request =
              controller.requests[
                  index];

          final appointmentId =
              request['id']
                  ?.toString();

          if (appointmentId == null) {
            return const SizedBox
                .shrink();
          }

          return RequestCard(
            request: request,
            isProcessing:
                controller
                    .isActionLoading,
            onConfirm: () =>
                _confirmRequest(
              context,
              controller,
              appointmentId,
            ),
            onReject: () =>
                _rejectRequest(
              context,
              controller,
              appointmentId,
            ),
          );
        },
      ),
    );
  }
}