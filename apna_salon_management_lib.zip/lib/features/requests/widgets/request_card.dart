import 'package:flutter/material.dart';

class RequestCard extends StatelessWidget {
  const RequestCard({
    super.key,
    required this.request,
    required this.onConfirm,
    required this.onReject,
    this.isProcessing = false,
  });

  final Map<String, dynamic> request;

  final VoidCallback onConfirm;

  final VoidCallback onReject;

  final bool isProcessing;

  String _value(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    final text = value.toString();

    return text.isEmpty ? '-' : text;
  }

  String _formatDate(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    try {
      final date =
          DateTime.parse(
        value.toString(),
      );

      return '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year}';
    } catch (_) {
      return value.toString();
    }
  }

  String _formatTime(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    final text = value.toString();

    if (text.length >= 5) {
      return text.substring(0, 5);
    }

    return text;
  }

  String _customerName() {
    final profile =
        request['profiles'];

    if (profile is Map) {
      return _value(
        profile['name'],
      );
    }

    return 'User';
  }

  String _customerPhone() {
    final profile =
        request['profiles'];

    if (profile is Map) {
      return _value(
        profile['phone'],
      );
    }

    return '-';
  }

  String _staffName() {
    final staff =
        request['staff'];

    if (staff is Map) {
      return _value(
        staff['name'],
      );
    }

    return _value(
      request['barber_name_snapshot'],
    );
  }

  String _servicesText() {
    final services =
        request['appointment_services'];

    if (services is! List ||
        services.isEmpty) {
      return 'No service details';
    }

    return services.map((service) {
      if (service is Map) {
        final name =
            _value(
          service[
              'service_name_snapshot'],
        );

        final price =
            service[
                'price_snapshot'];

        return price == null
            ? name
            : '$name (₹$price)';
      }

      return service.toString();
    }).join(', ');
  }

  String _durationText() {
    final duration =
        request[
            'total_duration_minutes'];

    return duration == null
        ? '-'
        : '$duration min';
  }

  String _priceText() {
    final price =
        request['total_price'];

    return price == null
        ? '₹0'
        : '₹$price';
  }

  @override
  Widget build(BuildContext context) {
    final theme =
        Theme.of(context);

    return Card(
      margin:
          const EdgeInsets.only(
        bottom: 14,
      ),
      elevation: 2,
      child: Padding(
        padding:
            const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            // ======================================================
            // HEADER
            // ======================================================

            Row(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 24,
                  child: Text(
                    _customerName()
                            .isNotEmpty
                        ? _customerName()[0]
                            .toUpperCase()
                        : '?',
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        _customerName(),
                        style: theme
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              fontWeight:
                                  FontWeight.bold,
                            ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        _customerPhone(),
                        style: theme
                            .textTheme
                            .bodySmall,
                      ),
                    ],
                  ),
                ),

                Container(
                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration:
                      BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(
                      20,
                    ),
                    color: Colors.orange
                        .withValues(
                      alpha: 0.12,
                    ),
                  ),
                  child: const Text(
                    'PENDING',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 18),

            // ======================================================
            // DATE / TIME
            // ======================================================

            Row(
              children: [
                const Icon(
                  Icons.calendar_today_outlined,
                  size: 18,
                ),

                const SizedBox(width: 8),

                Text(
                  _formatDate(
                    request[
                        'booking_date'],
                  ),
                ),

                const SizedBox(width: 18),

                const Icon(
                  Icons.access_time,
                  size: 18,
                ),

                const SizedBox(width: 8),

                Text(
                  '${_formatTime(request['start_time'])}'
                  ' - '
                  '${_formatTime(request['end_time'])}',
                ),
              ],
            ),

            const SizedBox(height: 14),

            // ======================================================
            // SERVICES
            // ======================================================

            _InfoRow(
              icon:
                  Icons.content_cut_outlined,
              title: 'Services',
              value: _servicesText(),
            ),

            const SizedBox(height: 10),

            // ======================================================
            // STAFF
            // ======================================================

            _InfoRow(
              icon:
                  Icons.person_outline,
              title: 'Staff',
              value: _staffName(),
            ),

            const SizedBox(height: 10),

            // ======================================================
            // TOTAL DURATION
            // ======================================================

            _InfoRow(
              icon:
                  Icons.timer_outlined,
              title: 'Duration',
              value: _durationText(),
            ),

            const SizedBox(height: 10),

            // ======================================================
            // TOTAL PRICE
            // ======================================================

            _InfoRow(
              icon:
                  Icons.currency_rupee,
              title: 'Total',
              value: _priceText(),
              valueBold: true,
            ),

            const SizedBox(height: 18),

            const Divider(),

            const SizedBox(height: 10),

            // ======================================================
            // ACTIONS
            // ======================================================

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed:
                        isProcessing
                            ? null
                            : onReject,
                    style:
                        OutlinedButton.styleFrom(
                      minimumSize:
                          const Size(
                        0,
                        46,
                      ),
                    ),
                    child:
                        const Text(
                      'Reject',
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: FilledButton(
                    onPressed:
                        isProcessing
                            ? null
                            : onConfirm,
                    style:
                        FilledButton.styleFrom(
                      minimumSize:
                          const Size(
                        0,
                        46,
                      ),
                    ),
                    child:
                        isProcessing
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth:
                                      2,
                                ),
                              )
                            : const Text(
                                'Confirm',
                              ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.title,
    required this.value,
    this.valueBold = false,
  });

  final IconData icon;

  final String title;

  final String value;

  final bool valueBold;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 19,
        ),

        const SizedBox(width: 10),

        SizedBox(
          width: 80,
          child: Text(
            title,
            style: const TextStyle(
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ),

        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontWeight: valueBold
                  ? FontWeight.bold
                  : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }
}