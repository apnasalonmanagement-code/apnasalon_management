import 'package:flutter/foundation.dart';

import '../../../repositories/availability_repository.dart';

class UrgentTimeController extends ChangeNotifier {
  UrgentTimeController({
    required this.shopId,
    required this.staffId,
    required this.bookingDate,
    required this.durationMinutes,
    AvailabilityRepository? repository,
  }) : _repository = repository ?? AvailabilityRepository() {
    loadTimes();
  }

  final String shopId;
  final String staffId;
  final DateTime bookingDate;
  final int durationMinutes;

  final AvailabilityRepository _repository;

  bool isLoading = false;
  String? errorMessage;

  List<String> times = <String>[];
  String? selectedTime;

  Future<void> loadTimes() async {
    isLoading = true;
    errorMessage = null;
    selectedTime = null;
    notifyListeners();

    try {
      if (shopId.trim().isEmpty) {
        throw Exception('Shop information is missing.');
      }

      if (staffId.trim().isEmpty) {
        throw Exception('Staff information is missing.');
      }

      if (durationMinutes <= 0) {
        throw Exception(
          'Service duration must be greater than zero.',
        );
      }

      final result = await _repository.getUrgentStartTimes(
        shopId: shopId,
        staffId: staffId,
        date: bookingDate,
        durationMinutes: durationMinutes,
      );

      times = result;
    } catch (e) {
      times = <String>[];

      errorMessage = _cleanErrorMessage(e);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void selectTime(String time) {
    if (!times.contains(time)) {
      return;
    }

    selectedTime = time;
    notifyListeners();
  }

  String displayTime(String value) {
    final parts = value.split(':');

    if (parts.length < 2) {
      return value;
    }

    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);

    if (hour == null || minute == null) {
      return value;
    }

    final isPm = hour >= 12;
    final displayHour = hour % 12 == 0 ? 12 : hour % 12;

    return '$displayHour:${minute.toString().padLeft(2, '0')} '
        '${isPm ? 'PM' : 'AM'}';
  }

  String _cleanErrorMessage(Object error) {
    final message = error.toString();

    if (message.startsWith('Exception: ')) {
      return message.substring('Exception: '.length);
    }

    return message;
  }
}