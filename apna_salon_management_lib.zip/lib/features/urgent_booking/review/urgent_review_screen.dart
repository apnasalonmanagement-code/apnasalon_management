import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'urgent_review_controller.dart';

class UrgentReviewScreen extends StatelessWidget {
  const UrgentReviewScreen({
    super.key,
    required this.shopId,
    required this.customerId,
    required this.bookingDate,
    required this.selectedServices,
    required this.selectedStaff,
    required this.selectedTime,
    required this.totalDuration,
    required this.totalPrice,
  });

  final String shopId;
  final String customerId;
  final DateTime bookingDate;
  final List<Map<String, dynamic>> selectedServices;
  final Map<String, dynamic> selectedStaff;
  final String selectedTime;
  final int totalDuration;
  final double totalPrice;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UrgentReviewController(
        shopId: shopId,
        customerId: customerId,
        bookingDate: bookingDate,
        selectedServices: selectedServices,
        selectedStaff: selectedStaff,
        selectedTime: selectedTime,
        totalDuration: totalDuration,
        totalPrice: totalPrice,
      ),
      child: const _UrgentReviewView(),
    );
  }
}

class _UrgentReviewView extends StatelessWidget {
  const _UrgentReviewView();

  Future<void> _book(BuildContext context, UrgentReviewController controller) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Confirm Urgent Booking'),
        content: const Text(
          'The time will be checked again by the database before the booking is created.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Back'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('BOOK NOW'),
          ),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    final success = await controller.createBooking();
    if (!context.mounted) return;

    if (success) {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.check_circle_outline, size: 48),
          title: const Text('Booking Confirmed'),
          content: const Text('Urgent appointment has been created successfully.'),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('DONE'),
            ),
          ],
        ),
      );

      if (!context.mounted) return;
      Navigator.popUntil(context, (route) => route.isFirst);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(controller.errorMessage ?? 'Unable to create booking.'),
          duration: const Duration(seconds: 5),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Review Booking')),
      body: Consumer<UrgentReviewController>(
        builder: (context, controller, _) {
          if (controller.isLoadingShop) {
            return const Center(child: CircularProgressIndicator());
          }

          if (controller.errorMessage != null && controller.shopName == 'Shop') {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(controller.errorMessage!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: controller.loadShop, child: const Text('Try Again')),
                  ],
                ),
              ),
            );
          }

          return SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _SummarySection(
                  title: 'Shop',
                  icon: Icons.store_outlined,
                  child: Text(
                    controller.shopName,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 12),
                _SummarySection(
                  title: 'Staff',
                  icon: Icons.person_outline,
                  child: Text(
                    controller.selectedStaff['name']?.toString() ?? 'Staff',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 12),
                _SummarySection(
                  title: 'Date & Time',
                  icon: Icons.calendar_month_outlined,
                  child: Text(
                    '${controller.dateText()}  •  ${controller.timeText()}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 16),
                _SummarySection(
                  title: 'Selected Services',
                  icon: Icons.content_cut_outlined,
                  child: Column(
                    children: controller.selectedServices
                        .map(
                          (service) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(
                              children: [
                                Expanded(child: Text(service['service_name']?.toString() ?? 'Service')),
                                Text('₹${_price(service['price'])}'),
                              ],
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _TotalRow(label: 'Total Duration', value: '${controller.totalDuration} minutes'),
                        const SizedBox(height: 10),
                        _TotalRow(label: 'Total Price', value: '₹${controller.totalPrice.toStringAsFixed(0)}', bold: true),
                        const SizedBox(height: 10),
                        const _TotalRow(label: 'Booking Type', value: 'Urgent'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  height: 54,
                  child: FilledButton(
                    onPressed: controller.isBooking ? null : () => _book(context, controller),
                    child: controller.isBooking
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('CONFIRM URGENT BOOKING'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  String _price(dynamic value) {
    if (value is num) return value.toStringAsFixed(0);
    return double.tryParse(value?.toString() ?? '')?.toStringAsFixed(0) ?? '0';
  }
}

class _SummarySection extends StatelessWidget {
  const _SummarySection({required this.title, required this.icon, required this.child});

  final String title;
  final IconData icon;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.labelLarge),
                  const SizedBox(height: 6),
                  child,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({required this.label, required this.value, this.bold = false});

  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(label)),
        Text(value, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.w500)),
      ],
    );
  }
}
