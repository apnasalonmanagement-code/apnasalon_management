import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/urgent_services_screen.dart';
import 'urgent_date_controller.dart';

class UrgentDateScreen extends StatelessWidget {
  const UrgentDateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UrgentDateController()..initialize(),
      child: const _UrgentDateView(),
    );
  }
}

class _UrgentDateView extends StatelessWidget {
  const _UrgentDateView();

  Future<void> _pickDate(BuildContext context, UrgentDateController controller) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: controller.selectedDate.isBefore(
        DateTime(now.year, now.month, now.day),
      )
          ? DateTime(now.year, now.month, now.day)
          : controller.selectedDate,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 1, now.month, now.day),
    );

    if (selected != null) {
      controller.selectDate(selected);
    }
  }

  void _continue(BuildContext context, UrgentDateController controller) {
    if (controller.shopId == null || controller.customerId == null) {
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UrgentServicesScreen(
          shopId: controller.shopId!,
          customerId: controller.customerId!,
          bookingDate: controller.selectedDate,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Urgent Booking')),
      body: Consumer<UrgentDateController>(
        builder: (context, controller, _) {
          if (controller.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (controller.errorMessage != null) {
            return _ErrorView(
              message: controller.errorMessage!,
              onRetry: controller.initialize,
            );
          }

          return SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const _StepHeader(
                  step: 1,
                  title: 'Select Date',
                  subtitle: 'When should the urgent appointment start?',
                ),
                const SizedBox(height: 24),
                _DateOption(
                  label: 'Today',
                  selected: controller.isToday(controller.selectedDate),
                  onTap: () => controller.selectDate(DateTime.now()),
                ),
                const SizedBox(height: 12),
                _DateOption(
                  label: 'Tomorrow',
                  selected: controller.isTomorrow(controller.selectedDate),
                  onTap: () => controller.selectDate(
                    DateTime.now().add(const Duration(days: 1)),
                  ),
                ),
                const SizedBox(height: 12),
                _DateOption(
                  label: 'Day After Tomorrow',
                  selected: controller.isDayAfterTomorrow(controller.selectedDate),
                  onTap: () => controller.selectDate(
                    DateTime.now().add(const Duration(days: 2)),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () => _pickDate(context, controller),
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: Text(controller.dateLabel(controller.selectedDate)),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                  ),
                ),
                const SizedBox(height: 28),
                FilledButton(
                  onPressed: controller.shopId == null
                      ? null
                      : () => _continue(context, controller),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                  ),
                  child: const Text('CONTINUE'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _StepHeader extends StatelessWidget {
  const _StepHeader({required this.step, required this.title, required this.subtitle});

  final int step;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CircleAvatar(child: Text('$step')),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(subtitle),
            ],
          ),
        ),
      ],
    );
  }
}

class _DateOption extends StatelessWidget {
  const _DateOption({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(
            color: selected
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).dividerColor,
            width: selected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off),
            const SizedBox(width: 12),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('Try Again')),
          ],
        ),
      ),
    );
  }
}
