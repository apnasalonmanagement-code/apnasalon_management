import 'package:flutter/material.dart';

import 'add_category/add_category_screen.dart';
import 'menu_controller.dart';
import 'widgets/category_item.dart';
import 'widgets/service_item.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({
    super.key,
  });

  @override
  State<MenuScreen> createState() =>
      _MenuScreenState();
}

class _MenuScreenState
    extends State<MenuScreen> {
  late final SalonMenuController _controller;

  @override
  void initState() {
    super.initState();

    _controller = SalonMenuController();

    _loadMenu();
  }

  // ============================================================
  // INITIAL LOAD
  // ============================================================

  Future<void> _loadMenu() async {
    await _controller.load();

    if (!mounted) {
      return;
    }

    _controller.startRealtime();

    setState(() {});
  }

  @override
  void dispose() {
    _controller.dispose();

    super.dispose();
  }

  // ============================================================
  // ADD CATEGORY
  // ============================================================

  Future<void> _addCategory() async {
    if (_controller.isLoading) {
      return;
    }

    final bool? created =
        await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            const AddCategoryScreen(),
      ),
    );

    if (!mounted) {
      return;
    }

    if (created == true) {
      await _controller.load();

      if (mounted) {
        setState(() {});
      }
    }
  }

  // ============================================================
  // RENAME CATEGORY
  // ============================================================

  Future<void> _renameCategory(
    String category,
  ) async {
    final TextEditingController
        textController =
        TextEditingController(
      text: category,
    );

    final GlobalKey<FormState>
        formKey =
        GlobalKey<FormState>();

    final String? newName =
        await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Rename Category',
          ),
          content: Form(
            key: formKey,
            child: TextFormField(
              controller: textController,
              autofocus: true,
              textCapitalization:
                  TextCapitalization.words,
              decoration:
                  const InputDecoration(
                labelText:
                    'Category Name',
                border:
                    OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null ||
                    value.trim().isEmpty) {
                  return
                      'Category name is required.';
                }

                return null;
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                );
              },
              child: const Text(
                'CANCEL',
              ),
            ),
            FilledButton(
              onPressed: () {
                if (!formKey.currentState!
                    .validate()) {
                  return;
                }

                Navigator.pop(
                  dialogContext,
                  textController
                      .text
                      .trim(),
                );
              },
              child: const Text(
                'SAVE',
              ),
            ),
          ],
        );
      },
    );

    textController.dispose();

    if (!mounted) {
      return;
    }

    if (newName == null ||
        newName.trim().isEmpty ||
        newName.trim() ==
            category.trim()) {
      return;
    }

    final bool success =
        await _controller.renameCategory(
      oldName: category,
      newName: newName.trim(),
    );

    if (!mounted) {
      return;
    }

    setState(() {});

    if (!success) {
      _showMessage(
        _controller.errorMessage ??
            'Unable to rename category.',
      );
    }
  }

  // ============================================================
  // CATEGORY ACTIONS
  // ============================================================

  Future<void> _showCategoryActions(
    String category,
  ) async {
    final String? action =
        await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(
                  Icons.edit_outlined,
                ),
                title: const Text(
                  'Rename Category',
                ),
                onTap: () {
                  Navigator.pop(
                    sheetContext,
                    'rename',
                  );
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.add_outlined,
                ),
                title: const Text(
                  'Add Service',
                ),
                onTap: () {
                  Navigator.pop(
                    sheetContext,
                    'add',
                  );
                },
              ),
            ],
          ),
        );
      },
    );

    if (!mounted) {
      return;
    }

    if (action == 'rename') {
      await _renameCategory(
        category,
      );
    }

    if (action == 'add') {
      await _addServiceToCategory(
        category,
      );
    }
  }

  // ============================================================
  // ADD SERVICE TO CATEGORY
  // ============================================================

  Future<void> _addServiceToCategory(
    String category,
  ) async {
    await showDialog<void>(
      context: context,
      builder: (_) {
        return _AddServiceDialog(
          controller: _controller,
          categoryName: category,
        );
      },
    );

    if (!mounted) {
      return;
    }

    setState(() {});
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
    String message,
  ) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (
        context,
        _,
      ) {
        return Scaffold(
          appBar: AppBar(
            title: const Text(
              'Menu',
            ),
            actions: [
              IconButton(
                tooltip: 'Refresh',
                onPressed:
                    _controller.isLoading
                        ? null
                        : () async {
                            await _controller
                                .load();

                            if (mounted) {
                              setState(
                                () {},
                              );
                            }
                          },
                icon: const Icon(
                  Icons.refresh,
                ),
              ),
            ],
          ),

          floatingActionButton:
              FloatingActionButton.extended(
            onPressed:
                _controller.isLoading
                    ? null
                    : _addCategory,
            icon: const Icon(
              Icons.add,
            ),
            label: const Text(
              'Add Category',
            ),
          ),

          body: _buildBody(),
        );
      },
    );
  }

  // ============================================================
  // BODY
  // ============================================================

  Widget _buildBody() {
    if (_controller.isLoading &&
        _controller.services.isEmpty) {
      return const Center(
        child:
            CircularProgressIndicator(),
      );
    }

    if (_controller.errorMessage !=
            null &&
        _controller.services.isEmpty) {
      return _ErrorState(
        message:
            _controller.errorMessage!,
        onRetry: () async {
          await _controller.load();

          if (mounted) {
            setState(() {});
          }
        },
      );
    }

    if (_controller.services.isEmpty) {
      return _EmptyMenuState(
        onAddCategory:
            _addCategory,
      );
    }

    final Map<String,
            List<dynamic>>
        groups =
        _controller.groupedServices;

    return RefreshIndicator(
      onRefresh: () async {
        await _controller.load();
      },
      child: ListView(
        padding:
            const EdgeInsets.fromLTRB(
          16,
          16,
          16,
          100,
        ),
        children: [
          if (_controller
                  .errorMessage !=
              null)
            Padding(
              padding:
                  const EdgeInsets.only(
                bottom: 12,
              ),
              child: MaterialBanner(
                content: Text(
                  _controller
                      .errorMessage!,
                ),
                actions: [
                  TextButton(
                    onPressed: () async {
                      await _controller
                          .load();
                    },
                    child:
                        const Text(
                      'RETRY',
                    ),
                  ),
                ],
              ),
            ),

          for (final category
              in _controller
                  .categories)
            CategoryItem(
              categoryName:
                  category,
              serviceCount:
                  groups[category]!
                      .length,
              onRename: () =>
                  _showCategoryActions(
                category,
              ),
              child: Column(
                children: [
                  for (final service
                      in groups[
                          category]!)
                    ServiceItem(
                      service:
                          service,
                    ),

                  Align(
                    alignment:
                        Alignment.centerLeft,
                    child:
                        TextButton.icon(
                      onPressed: () =>
                          _addServiceToCategory(
                        category,
                      ),
                      icon:
                          const Icon(
                        Icons.add,
                      ),
                      label:
                          const Text(
                        'Add Service',
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================
// EMPTY STATE
// ============================================================

class _EmptyMenuState
    extends StatelessWidget {
  const _EmptyMenuState({
    required this.onAddCategory,
  });

  final VoidCallback
      onAddCategory;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.all(24),
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            const Icon(
              Icons
                  .menu_book_outlined,
              size: 64,
            ),

            const SizedBox(
              height: 16,
            ),

            const Text(
              'No active services',
              style: TextStyle(
                fontSize: 20,
                fontWeight:
                    FontWeight.w700,
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            const Text(
              'Create a category with its first service to start your menu.',
              textAlign:
                  TextAlign.center,
            ),

            const SizedBox(
              height: 20,
            ),

            FilledButton.icon(
              onPressed:
                  onAddCategory,
              icon: const Icon(
                Icons.add,
              ),
              label:
                  const Text(
                'Add Category',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ERROR STATE
// ============================================================

class _ErrorState
    extends StatelessWidget {
  const _ErrorState({
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Center(
      child: Padding(
        padding:
            const EdgeInsets.all(24),
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline,
              size: 56,
            ),

            const SizedBox(
              height: 16,
            ),

            Text(
              message,
              textAlign:
                  TextAlign.center,
            ),

            const SizedBox(
              height: 20,
            ),

            FilledButton(
              onPressed:
                  onRetry,
              child:
                  const Text(
                'TRY AGAIN',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ADD SERVICE DIALOG
// ============================================================

class _AddServiceDialog
    extends StatefulWidget {
  const _AddServiceDialog({
    required this.controller,
    required this.categoryName,
  });

  final SalonMenuController controller;
  final String categoryName;

  @override
  State<_AddServiceDialog>
      createState() =>
          _AddServiceDialogState();
}

class _AddServiceDialogState
    extends State<
        _AddServiceDialog> {
  final GlobalKey<FormState>
      _formKey =
      GlobalKey<FormState>();

  final TextEditingController
      _nameController =
      TextEditingController();

  final TextEditingController
      _durationController =
      TextEditingController(
    text: '30',
  );

  final TextEditingController
      _priceController =
      TextEditingController(
    text: '0',
  );

  bool _request = false;
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _durationController.dispose();
    _priceController.dispose();

    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    final int? duration =
        int.tryParse(
      _durationController.text
          .trim(),
    );

    final double? price =
        double.tryParse(
      _priceController.text
          .trim(),
    );

    if (duration == null ||
        duration <= 0) {
      return;
    }

    if (price == null ||
        price < 0) {
      return;
    }

    setState(() {
      _saving = true;
    });

    final bool success =
        await widget.controller
            .addService(
      categoryName:
          widget.categoryName,
      serviceName:
          _nameController.text
              .trim(),
      durationMinutes:
          duration,
      price: price,
      request: _request,
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _saving = false;
    });

    if (success) {
      Navigator.pop(
        context,
      );
      return;
    }

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          widget.controller
                  .errorMessage ??
              'Unable to add service.',
        ),
      ),
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    return AlertDialog(
      title: Text(
        'Add Service to ${widget.categoryName}',
      ),
      content: Form(
        key: _formKey,
        child:
            SingleChildScrollView(
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              TextFormField(
                controller:
                    _nameController,
                decoration:
                    const InputDecoration(
                  labelText:
                      'Service Name',
                  border:
                      OutlineInputBorder(),
                ),
                validator:
                    (value) {
                  if (value ==
                          null ||
                      value
                          .trim()
                          .isEmpty) {
                    return
                        'Service name is required.';
                  }

                  return null;
                },
              ),

              const SizedBox(
                height: 12,
              ),

              TextFormField(
                controller:
                    _durationController,
                keyboardType:
                    TextInputType.number,
                decoration:
                    const InputDecoration(
                  labelText:
                      'Duration (minutes)',
                  border:
                      OutlineInputBorder(),
                ),
                validator:
                    (value) {
                  final int?
                      duration =
                      int.tryParse(
                    value?.trim() ??
                        '',
                  );

                  if (duration ==
                          null ||
                      duration <=
                          0) {
                    return
                        'Enter a valid duration.';
                  }

                  return null;
                },
              ),

              const SizedBox(
                height: 12,
              ),

              TextFormField(
                controller:
                    _priceController,
                keyboardType:
                    const TextInputType
                        .numberWithOptions(
                  decimal: true,
                ),
                decoration:
                    const InputDecoration(
                  labelText:
                      'Price',
                  border:
                      OutlineInputBorder(),
                ),
                validator:
                    (value) {
                  final double?
                      price =
                      double.tryParse(
                    value?.trim() ??
                        '',
                  );

                  if (price ==
                          null ||
                      price < 0) {
                    return
                        'Enter a valid price.';
                  }

                  return null;
                },
              ),

              SwitchListTile(
                contentPadding:
                    EdgeInsets.zero,
                title:
                    const Text(
                  'Request required',
                ),
                value:
                    _request,
                onChanged:
                    _saving
                        ? null
                        : (value) {
                            setState(
                              () {
                                _request =
                                    value;
                              },
                            );
                          },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed:
              _saving
                  ? null
                  : () {
                      Navigator.pop(
                        context,
                      );
                    },
          child:
              const Text(
            'CANCEL',
          ),
        ),
        FilledButton(
          onPressed:
              _saving
                  ? null
                  : _save,
          child: _saving
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child:
                      CircularProgressIndicator(
                    strokeWidth: 2,
                  ),
                )
              : const Text(
                  'ADD',
                ),
        ),
      ],
    );
  }
}