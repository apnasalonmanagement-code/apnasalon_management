import 'package:flutter/material.dart';

class CategoryItem extends StatelessWidget {
  const CategoryItem({
    super.key,
    required this.categoryName,
    required this.serviceCount,
    required this.onRename,
    required this.child,
  });

  final String categoryName;
  final int serviceCount;
  final VoidCallback onRename;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const CircleAvatar(
          child: Icon(Icons.category_outlined),
        ),
        title: Text(
          categoryName,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          '$serviceCount ${serviceCount == 1 ? 'service' : 'services'}',
        ),
        trailing: IconButton(
          tooltip: 'Manage category',
          onPressed: onRename,
          icon: const Icon(Icons.more_horiz),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: child,
          ),
        ],
      ),
    );
  }
}
