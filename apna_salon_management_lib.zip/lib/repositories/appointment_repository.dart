
import '../core/services/supabase_service.dart';

class AppointmentRepository {
  AppointmentRepository({SupabaseService? supabaseService})
      : _supabaseService =
            supabaseService ?? SupabaseService.instance;

  final SupabaseService _supabaseService;

  Future<Map<String, dynamic>> createUrgentBooking({
    required String shopId,
    required String staffId,
    required String customerId,
    required DateTime bookingDate,
    required String startTime,
    required List<String> serviceIds,
  }) async {
    final response = await _supabaseService.client.rpc(
      'create_urgent_booking',
      params: {
        'p_shop_id': shopId,
        'p_staff_id': staffId,
        'p_customer_id': customerId,
        'p_booking_date': _dateString(bookingDate),
        'p_start_time': _normalizeTime(startTime),
        'p_service_ids': serviceIds,
      },
    );

    if (response is Map<String, dynamic>) {
      return response;
    }

    if (response is Map) {
      return Map<String, dynamic>.from(response);
    }

    throw Exception('Unexpected booking response from Supabase.');
  }

  String _dateString(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';
  }

  String _normalizeTime(String value) {
    final text = value.trim();
    if (text.length == 5) return '$text:00';
    if (text.length >= 8) return text.substring(0, 8);
    throw Exception('Invalid booking time.');
  }
}
