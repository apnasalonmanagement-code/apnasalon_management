import 'package:flutter/material.dart';

import 'salon_controller.dart';
import 'edit_salon_screen.dart';

class SalonProfileScreen
    extends StatefulWidget {
  const SalonProfileScreen({
    super.key,
  });

  @override
  State<SalonProfileScreen> createState() =>
      _SalonProfileScreenState();
}

class _SalonProfileScreenState
    extends State<SalonProfileScreen> {
  late final SalonController c;

  @override
  void initState() {
    super.initState();

    c = SalonController()
      ..addListener(_refresh)
      ..load();
  }

  void _refresh() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    c.removeListener(_refresh);
    c.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = c.shop;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Shop Profile',
        ),
        actions: [
          IconButton(
            onPressed:
                s == null ? null : _edit,
            icon: const Icon(
              Icons.edit_outlined,
            ),
          ),
        ],
      ),
      body: c.isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(),
            )
          : s == null
              ? Center(
                  child: Padding(
                    padding:
                        const EdgeInsets.all(
                      24,
                    ),
                    child: Column(
                      mainAxisSize:
                          MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.store_outlined,
                          size: 56,
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        Text(
                          c.errorMessage ??
                              'Shop information unavailable.',
                          textAlign:
                              TextAlign.center,
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        FilledButton(
                          onPressed: c.load,
                          child: const Text(
                            'Retry',
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: c.load,
                  child: ListView(
                    padding:
                        const EdgeInsets.all(
                      16,
                    ),
                    children: [
                      if ((s['image_url'] ?? '')
                          .toString()
                          .isNotEmpty)
                        ClipRRect(
                          borderRadius:
                              BorderRadius.circular(
                            16,
                          ),
                          child: Image.network(
                            s['image_url']
                                .toString(),
                            height: 190,
                            width:
                                double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder:
                                (
                              _,
                              __,
                              ___,
                            ) =>
                                    _placeholder(),
                          ),
                        )
                      else
                        _placeholder(),

                      const SizedBox(
                        height: 16,
                      ),

                      Text(
                        s['shop_name']
                                ?.toString() ??
                            '',
                        style: Theme.of(context)
                            .textTheme
                            .headlineSmall
                            ?.copyWith(
                              fontWeight:
                                  FontWeight.bold,
                            ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        '${s['city'] ?? ''} • '
                        '${s['status'] == true ? 'Active' : 'Inactive'}',
                      ),

                      const Divider(
                        height: 28,
                      ),

                      _row(
                        Icons.phone,
                        'Phone',
                        s['phone'],
                      ),

                      _row(
                        Icons.location_city,
                        'City',
                        s['city'],
                      ),

                      _row(
                        Icons.storefront_outlined,
                        'Shop Type',
                        _formatShopType(s['shop_type']),
                      ),

                      _row(
                        Icons.link,
                        'Location URL',
                        s['location_url'],
                      ),

                      _row(
                        Icons.description_outlined,
                        'Description',
                        s['description'],
                      ),

                      _row(
                        Icons.schedule,
                        'Opening',
                        s['opening_time'],
                      ),

                      _row(
                        Icons.schedule_outlined,
                        'Closing',
                        s['closing_time'],
                      ),

                      const SizedBox(
                        height: 16,
                      ),

                      FilledButton.icon(
                        onPressed: _edit,
                        icon: const Icon(
                          Icons.edit,
                        ),
                        label: const Text(
                          'Edit Shop',
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _placeholder() {
    return Container(
      height: 190,
      decoration: BoxDecoration(
        color: Theme.of(context)
            .colorScheme
            .surfaceContainerHighest,
        borderRadius:
            BorderRadius.circular(16),
      ),
      child: const Icon(
        Icons.store,
        size: 64,
      ),
    );
  }

  String _formatShopType(dynamic value) {
    switch (value?.toString()) {
      case 'parlour':
        return 'Parlour';
      case 'unisexsalon':
        return 'Unisex Salon';
      case 'salon':
        return 'Salon';
      default:
        return 'Not set';
    }
  }

  Widget _row(
    IconData icon,
    String label,
    dynamic value,
  ) {
    return ListTile(
      contentPadding:
          EdgeInsets.zero,
      leading: Icon(icon),
      title: Text(label),
      subtitle: Text(
        value == null ||
                value
                    .toString()
                    .trim()
                    .isEmpty
            ? 'Not set'
            : value.toString(),
      ),
    );
  }

  Future<void> _edit() async {
    final changed =
        await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            EditSalonScreen(
          initial:
              Map<String, dynamic>.from(
            c.shop!,
          ),
        ),
      ),
    );

    if (changed == true) {
      c.load();
    }
  }
}