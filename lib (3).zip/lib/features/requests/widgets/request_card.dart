import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class RequestCard extends StatefulWidget {
  const RequestCard({
    super.key,
    required this.request,
    required this.onConfirm,
    required this.onReject,
    this.onSaveInstruction,
    this.isProcessing = false,
  });

  final Map<String, dynamic> request;

  final ValueChanged<String> onConfirm;

  final ValueChanged<String> onReject;

  final ValueChanged<String>? onSaveInstruction;

  final bool isProcessing;

  @override
  State<RequestCard> createState() => _RequestCardState();
}

class _RequestCardState extends State<RequestCard> {
  late final TextEditingController _instructionController;

  @override
  void initState() {
    super.initState();

    _instructionController =
        TextEditingController(
      text:
          widget.request[
                  'shop_instruction']
              ?.toString() ??
              '',
    );
  }

  @override
  void dispose() {
    _instructionController.dispose();

    super.dispose();
  }

  String _value(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    final text =
        value
            .toString()
            .trim();

    return text.isEmpty
        ? '-'
        : text;
  }

  String _customerName() {
    final directName =
        widget.request[
            '_customer_name'];

    if (directName != null) {
      final name =
          _value(
        directName,
      );

      if (name != '-') {
        return name;
      }
    }

    final profile =
        widget.request[
            'profiles'];

    if (profile is Map) {
      final name =
          _value(
        profile['name'],
      );

      if (name != '-') {
        return name;
      }
    }

    return 'Customer';
  }

  String _customerPhone() {
    final directPhone =
        widget.request[
            '_customer_phone'];

    if (directPhone != null) {
      final phone =
          _value(
        directPhone,
      );

      if (phone != '-') {
        return phone;
      }
    }

    final profile =
        widget.request[
            'profiles'];

    if (profile is Map) {
      return _value(
        profile['phone'],
      );
    }

    return '-';
  }

  String _staffName() {
    final directName =
        widget.request[
            '_staff_name'];

    if (directName != null) {
      final name =
          _value(
        directName,
      );

      if (name != '-') {
        return name;
      }
    }

    final staff =
        widget.request[
            'staff'];

    if (staff is Map) {
      final name =
          _value(
        staff['name'],
      );

      if (name != '-') {
        return name;
      }
    }

    return _value(
      widget.request[
          'barber_name_snapshot'],
    );
  }

  String _staffPhone() {
    final directPhone =
        widget.request[
            '_staff_phone'];

    if (directPhone != null) {
      final phone =
          _value(
        directPhone,
      );

      if (phone != '-') {
        return phone;
      }
    }

    final staff =
        widget.request[
            'staff'];

    if (staff is Map) {
      return _value(
        staff['phone'],
      );
    }

    return '-';
  }

  String _formatDate(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    try {
      final date =
          DateTime.parse(
        value.toString(),
      );

      return '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year}';
    } catch (_) {
      return _value(value);
    }
  }

  String _formatTime(
    dynamic value,
  ) {
    if (value == null) {
      return '-';
    }

    final text =
        value
            .toString()
            .trim();

    if (text.length >= 5) {
      return text.substring(
        0,
        5,
      );
    }

    return text.isEmpty
        ? '-'
        : text;
  }

  List<Map<String, dynamic>>
      _services() {
    final value =
        widget.request[
                '_services'] ??
            widget.request[
                'services'] ??
            widget.request[
                'appointment_services'];

    if (value is List) {
      return value
          .whereType<Map>()
          .map(
            (
              service,
            ) =>
                Map<String, dynamic>.from(
              service,
            ),
          )
          .toList();
    }

    if (value is Map) {
      return [
        Map<String, dynamic>.from(
          value,
        ),
      ];
    }

    return [];
  }

  String _number(
    dynamic value,
  ) {
    if (value is num) {
      return value
          .toStringAsFixed(0);
    }

    return double.tryParse(
              value
                      ?.toString() ??
                  '',
            )
            ?.toStringAsFixed(0) ??
        '0';
  }

  String _servicesText() {
    final services =
        _services();

    if (services.isEmpty) {
      return 'No service details';
    }

    return services.map(
      (
        service,
      ) {
        final name =
            _value(
          service[
                  'service_name'] ??
              service[
                  'service_name_snapshot'],
        );

        final price =
            service[
                    'price'] ??
                service[
                    'price_snapshot'];

        final duration =
            service[
                    'duration_minutes'] ??
                service[
                    'duration'];

        final details =
            <String>[];

        if (duration !=
            null) {
          details.add(
            '$duration min',
          );
        }

        if (price !=
            null) {
          details.add(
            '₹${_number(price)}',
          );
        }

        if (details.isEmpty) {
          return name;
        }

        return '$name (${details.join(' • ')})';
      },
    ).join(', ');
  }

  String _durationText() {
    final duration =
        widget.request[
            'total_duration_minutes'];

    return duration == null
        ? '-'
        : '$duration min';
  }

  String _priceText() {
    final price =
        widget.request[
            'total_price'];

    return price == null
        ? '₹0'
        : '₹${_number(price)}';
  }

  Future<void> _call(
    BuildContext context,
    String phone,
  ) async {
    if (phone == '-' ||
        phone.trim().isEmpty) {
      return;
    }

    final uri =
        Uri(
      scheme: 'tel',
      path: phone.trim(),
    );

    try {
      if (await canLaunchUrl(
        uri,
      )) {
        await launchUrl(
          uri,
          mode:
              LaunchMode
                  .externalApplication,
        );
      } else if (context
          .mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(
          const SnackBar(
            content: Text(
              'Unable to open phone dialer.',
            ),
          ),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(
          const SnackBar(
            content: Text(
              'Could not open phone dialer.',
            ),
          ),
        );
      }
    }
  }

  Widget _infoRow(
    IconData icon,
    String title,
    String value, {
    bool bold = false,
  }) {
    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 19,
        ),

        const SizedBox(
          width: 10,
        ),

        SizedBox(
          width: 80,
          child: Text(
            title,
            style:
                const TextStyle(
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ),

        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontWeight: bold
                  ? FontWeight.bold
                  : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final theme =
        Theme.of(context);

    final phone =
        _customerPhone();

    final staffPhone =
        _staffPhone();

    return Card(
      margin:
          const EdgeInsets.only(
        bottom: 14,
      ),
      elevation: 2,
      child: Padding(
        padding:
            const EdgeInsets.all(
          16,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            // ======================================================
            // HEADER
            // ======================================================

            Row(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 24,
                  child: Text(
                    _customerName()
                            .isNotEmpty
                        ? _customerName()[
                                0]
                            .toUpperCase()
                        : '?',
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        _customerName(),
                        style: theme
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                          fontWeight:
                              FontWeight
                                  .bold,
                        ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        phone,
                        style: theme
                            .textTheme
                            .bodySmall,
                      ),
                    ],
                  ),
                ),

                Container(
                  padding:
                      const EdgeInsets
                          .symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration:
                      BoxDecoration(
                    borderRadius:
                        BorderRadius
                            .circular(
                      20,
                    ),
                    color: Colors
                        .orange
                        .withValues(
                      alpha: 0.12,
                    ),
                  ),
                  child:
                      const Text(
                    'PENDING',
                    style:
                        TextStyle(
                      fontSize: 11,
                      fontWeight:
                          FontWeight
                              .bold,
                    ),
                  ),
                ),
              ],
            ),

            // ======================================================
            // CALL CUSTOMER
            // ======================================================

            if (phone != '-')
              ...[
                Align(
                  alignment:
                      Alignment
                          .centerRight,
                  child:
                      OutlinedButton
                          .icon(
                    onPressed:
                        () => _call(
                      context,
                      phone,
                    ),
                    icon:
                        const Icon(
                      Icons.call,
                      size: 18,
                    ),
                    label:
                        const Text(
                      'Call Customer',
                    ),
                  ),
                ),
              ],

            const SizedBox(
              height: 6,
            ),

            // ======================================================
            // DATE
            // ======================================================

            _infoRow(
              Icons
                  .calendar_today_outlined,
              'Date',
              _formatDate(
                widget.request[
                    'booking_date'],
              ),
            ),

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // TIME
            // ======================================================

            _infoRow(
              Icons.access_time,
              'Time',
              '${_formatTime(widget.request['start_time'])}'
              ' - '
              '${_formatTime(widget.request['end_time'])}',
            ),

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // STAFF
            // ======================================================

            _infoRow(
              Icons.person_outline,
              'Staff',
              _staffName(),
            ),

            // ======================================================
            // STAFF PHONE
            // ======================================================

            if (staffPhone != '-')
              ...[
                const SizedBox(
                  height: 8,
                ),

                _infoRow(
                  Icons.phone_outlined,
                  'Staff Phone',
                  staffPhone,
                ),
              ],

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // SERVICES
            // ======================================================

            _infoRow(
              Icons
                  .content_cut_outlined,
              'Services',
              _servicesText(),
            ),

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // TOTAL DURATION
            // ======================================================

            _infoRow(
              Icons.timer_outlined,
              'Duration',
              _durationText(),
            ),

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // TOTAL PRICE
            // ======================================================

            _infoRow(
              Icons.currency_rupee,
              'Total',
              _priceText(),
              bold: true,
            ),

            const SizedBox(
              height: 18,
            ),

            // ======================================================
            // SHOP INSTRUCTION
            // ======================================================

            TextField(
              controller:
                  _instructionController,
              maxLines: 3,
              maxLength: 250,
              enabled:
                  !widget.isProcessing,
              decoration:
                  const InputDecoration(
                labelText:
                    'Shop instruction',
                hintText:
                    'Message for confirm/reject or general instruction',
                border:
                    OutlineInputBorder(),
              ),
            ),

            // ======================================================
            // SAVE INSTRUCTION
            // ======================================================

            if (widget
                    .onSaveInstruction !=
                null)
              Align(
                alignment:
                    Alignment
                        .centerRight,
                child:
                    OutlinedButton
                        .icon(
                  onPressed:
                      widget.isProcessing
                          ? null
                          : () {
                              widget
                                  .onSaveInstruction!(
                                _instructionController
                                    .text
                                    .trim(),
                              );
                            },
                  icon:
                      const Icon(
                    Icons
                        .save_outlined,
                    size: 18,
                  ),
                  label:
                      const Text(
                    'Save Instruction',
                  ),
                ),
              ),

            const SizedBox(
              height: 8,
            ),

            const Divider(),

            const SizedBox(
              height: 10,
            ),

            // ======================================================
            // ACTIONS
            // ======================================================

            Row(
              children: [
                Expanded(
                  child:
                      OutlinedButton(
                    onPressed:
                        widget.isProcessing
                            ? null
                            : () {
                                widget
                                    .onReject(
                                  _instructionController
                                      .text
                                      .trim(),
                                );
                              },
                    style:
                        OutlinedButton
                            .styleFrom(
                      minimumSize:
                          const Size(
                        0,
                        46,
                      ),
                    ),
                    child:
                        const Text(
                      'Reject',
                    ),
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child:
                      FilledButton(
                    onPressed:
                        widget.isProcessing
                            ? null
                            : () {
                                widget
                                    .onConfirm(
                                  _instructionController
                                      .text
                                      .trim(),
                                );
                              },
                    style:
                        FilledButton
                            .styleFrom(
                      minimumSize:
                          const Size(
                        0,
                        46,
                      ),
                    ),
                    child:
                        widget
                                .isProcessing
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth:
                                      2,
                                ),
                              )
                            : const Text(
                                'Confirm',
                              ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}