import 'package:flutter/material.dart';

import '../../../models/service_model.dart';

class ServiceItem extends StatelessWidget {
  const ServiceItem({
    super.key,
    required this.service,
    this.onTap,
  });

  final ServiceModel service;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final currency = service.price.toStringAsFixed(0);

    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      leading: CircleAvatar(
        radius: 24,
        backgroundImage: service.imageUrl != null && service.imageUrl!.isNotEmpty
            ? NetworkImage(service.imageUrl!)
            : null,
        child: service.imageUrl == null || service.imageUrl!.isEmpty
            ? const Icon(Icons.content_cut_outlined)
            : null,
      ),
      title: Text(
        service.serviceName,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Wrap(
          spacing: 10,
          runSpacing: 4,
          children: [
            Text('${service.durationMinutes} min'),
            if (service.request)
              const Text(
                'Request required',
                style: TextStyle(fontWeight: FontWeight.w500),
              ),
          ],
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '₹$currency',
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(width: 4),
          const Icon(Icons.edit_outlined, size: 18),
        ],
      ),
    );
  }
}
