import 'package:flutter/material.dart';

import '../../core/services/auth_service.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final AuthService _auth = AuthService();

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _appointments = [];
  List<Map<String, dynamic>> _staff = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('Your session has expired. Please log in again.');

      final profile = await _auth.getProfile(user.id);
      if (profile == null) throw Exception('Management profile not found.');

      final role = profile['role']?.toString();
      if (role != 'owner' && role != 'manager') {
        throw Exception('You are not authorized to view reports.');
      }

      final shopId = profile['shop_id']?.toString();
      if (shopId == null || shopId.isEmpty || shopId == 'null') {
        throw Exception('No shop is assigned to this account.');
      }

      final appointments = await _auth.client
          .from('appointments')
          .select('id, staff_id, status, total_price, booking_date, start_time, end_time')
          .eq('shop_id', shopId);

      final staff = await _auth.client
          .from('staff')
          .select('id, name, role, status')
          .eq('shop_id', shopId)
          .order('name');

      _appointments = List<Map<String, dynamic>>.from(appointments);
      _staff = List<Map<String, dynamic>>.from(staff);
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  int _count(String status) => _appointments
      .where((a) => a['status']?.toString().toLowerCase() == status)
      .length;

  double _revenue(Iterable<Map<String, dynamic>> items) {
    return items
        .where((a) => a['status']?.toString().toLowerCase() == 'completed')
        .fold<double>(0, (sum, a) {
      final value = a['total_price'];
      return sum + (value is num ? value.toDouble() : double.tryParse(value?.toString() ?? '') ?? 0);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline, size: 52),
                        const SizedBox(height: 12),
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _load, child: const Text('Try Again')),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Text('Overall Shop Dashboard', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.6,
                        children: [
                          _MetricCard(label: 'Total', value: '${_appointments.length}', icon: Icons.calendar_month),
                          _MetricCard(label: 'Completed', value: '${_count('completed')}', icon: Icons.check_circle_outline),
                          _MetricCard(label: 'Pending', value: '${_count('pending')}', icon: Icons.pending_actions),
                          _MetricCard(label: 'Cancelled / Rejected', value: '${_count('cancelled') + _count('rejected')}', icon: Icons.cancel_outlined),
                        ],
                      ),
                      const SizedBox(height: 18),
                      _ChartCard(
                        title: 'Appointments by Status',
                        values: {
                          'Completed': _count('completed').toDouble(),
                          'Confirmed': _count('confirmed').toDouble(),
                          'Pending': _count('pending').toDouble(),
                          'Cancelled': _count('cancelled').toDouble(),
                          'Rejected': _count('rejected').toDouble(),
                        },
                      ),
                      const SizedBox(height: 18),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              const Icon(Icons.currency_rupee),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Text('Completed Revenue', style: TextStyle(fontWeight: FontWeight.w600)),
                              ),
                              Text(
                                '₹${_revenue(_appointments).toStringAsFixed(0)}',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text('Employee-wise Dashboard', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      if (_staff.isEmpty)
                        const Card(
                          child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Text('No staff members found.'),
                          ),
                        )
                      else
                        ..._staff.map((staff) {
                          final id = staff['id']?.toString();
                          final items = _appointments.where((a) => a['staff_id']?.toString() == id).toList();
                          final completed = items.where((a) => a['status']?.toString().toLowerCase() == 'completed').length;
                          final confirmed = items.where((a) => a['status']?.toString().toLowerCase() == 'confirmed').length;
                          final pending = items.where((a) => a['status']?.toString().toLowerCase() == 'pending').length;
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: Card(
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        CircleAvatar(
                                          child: Text((staff['name']?.toString().trim().isNotEmpty == true)
                                              ? staff['name'].toString().trim()[0].toUpperCase()
                                              : '?'),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            staff['name']?.toString() ?? 'Staff',
                                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                                          ),
                                        ),
                                        Text('₹${_revenue(items).toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                    const SizedBox(height: 14),
                                    _ChartCard(
                                      title: 'Appointment Chart',
                                      values: {
                                        'Completed': completed.toDouble(),
                                        'Confirmed': confirmed.toDouble(),
                                        'Pending': pending.toDouble(),
                                        'Cancelled': items.where((a) => a['status']?.toString().toLowerCase() == 'cancelled').length.toDouble(),
                                        'Rejected': items.where((a) => a['status']?.toString().toLowerCase() == 'rejected').length.toDouble(),
                                      },
                                    ),
                                    const SizedBox(height: 10),
                                    Wrap(
                                      spacing: 14,
                                      runSpacing: 8,
                                      children: [
                                        Text('Total: ${items.length}'),
                                        Text('Completed: $completed'),
                                        Text('Pending: $pending'),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }),
                    ],
                  ),
                ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon),
            const Spacer(),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  const _ChartCard({required this.title, required this.values});
  final String title;
  final Map<String, double> values;

  @override
  Widget build(BuildContext context) {
    final max = values.values.fold<double>(0, (a, b) => a > b ? a : b);

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            ...values.entries.map((entry) {
              final ratio = max <= 0 ? 0.0 : entry.value / max;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    SizedBox(width: 92, child: Text(entry.key, maxLines: 1, overflow: TextOverflow.ellipsis)),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: ratio,
                          minHeight: 12,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    SizedBox(width: 32, child: Text(entry.value.toInt().toString(), textAlign: TextAlign.end)),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
