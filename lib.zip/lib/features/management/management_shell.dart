import 'package:flutter/material.dart';

import '../appointments/appointments_screen.dart';
import '../requests/requests_screen.dart';

class ManagementShell
    extends StatefulWidget {
  const ManagementShell({
    super.key,
    this.initialIndex = 1,
  });

  final int initialIndex;

  @override
  State<ManagementShell> createState() =>
      _ManagementShellState();
}

class _ManagementShellState
    extends State<ManagementShell> {
  late int _currentIndex;

  @override
  void initState() {
    super.initState();

    // Requests = index 1
    _currentIndex =
        widget.initialIndex;
  }

  void _onNavigationTap(
    int index,
  ) {
    setState(() {
      _currentIndex = index;
    });
  }

  Widget _buildPage() {
    switch (_currentIndex) {
      case 0:
        return const AppointmentsScreen();

      case 1:
        return const RequestsScreen();

      case 2:
        return const _ComingSoonPage(
          title: 'Menu',
        );

      case 3:
        return const _ComingSoonPage(
          title: 'Book',
        );

      case 4:
        return const _ComingSoonPage(
          title: 'Profile',
        );

      default:
        return const RequestsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: const [
          AppointmentsScreen(),
          RequestsScreen(),
          _ComingSoonPage(
            title: 'Menu',
          ),
          _ComingSoonPage(
            title: 'Book',
          ),
          _ComingSoonPage(
            title: 'Profile',
          ),
        ],
      ),

      bottomNavigationBar:
          NavigationBar(
        selectedIndex:
            _currentIndex,
        onDestinationSelected:
            _onNavigationTap,
        destinations: const [
          NavigationDestination(
            icon: Icon(
              Icons.calendar_month_outlined,
            ),
            selectedIcon: Icon(
              Icons.calendar_month,
            ),
            label: 'Appointments',
          ),
          NavigationDestination(
            icon: Icon(
              Icons.inbox_outlined,
            ),
            selectedIcon: Icon(
              Icons.inbox,
            ),
            label: 'Requests',
          ),
          NavigationDestination(
            icon: Icon(
              Icons.menu_book_outlined,
            ),
            selectedIcon: Icon(
              Icons.menu_book,
            ),
            label: 'Menu',
          ),
          NavigationDestination(
            icon: Icon(
              Icons.add_circle_outline,
            ),
            selectedIcon: Icon(
              Icons.add_circle,
            ),
            label: 'Book',
          ),
          NavigationDestination(
            icon: Icon(
              Icons.person_outline,
            ),
            selectedIcon: Icon(
              Icons.person,
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class _ComingSoonPage
    extends StatelessWidget {
  const _ComingSoonPage({
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Text(
          '$title\nComing in a later part.',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}