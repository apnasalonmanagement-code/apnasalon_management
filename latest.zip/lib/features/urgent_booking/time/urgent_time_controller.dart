import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../repositories/availability_repository.dart';

class UrgentTimeController extends ChangeNotifier {
  UrgentTimeController({
    required this.shopId,
    required this.staffId,
    required this.bookingDate,
    required this.durationMinutes,
    AvailabilityRepository? repository,
  }) : _repository = repository ?? AvailabilityRepository() {
    loadTimes();
    _subscribeToAppointmentChanges();
  }

  final String shopId;
  final String staffId;
  final DateTime bookingDate;
  final int durationMinutes;
  final AvailabilityRepository _repository;
  final SupabaseClient _supabase = Supabase.instance.client;

  bool isLoading = false;
  String? errorMessage;
  List<String> times = <String>[];
  String? selectedTime;
  RealtimeChannel? _realtimeChannel;
  bool _disposed = false;

  Future<void> loadTimes() async {
    if (_disposed) return;
    isLoading = true;
    errorMessage = null;
    selectedTime = null;
    notifyListeners();
    try {
      if (shopId.trim().isEmpty) throw Exception('Shop information is missing.');
      if (staffId.trim().isEmpty) throw Exception('Staff information is missing.');
      if (durationMinutes <= 0) throw Exception('Service duration must be greater than zero.');
      times = await _repository.getUrgentStartTimes(
        shopId: shopId,
        staffId: staffId,
        date: bookingDate,
        durationMinutes: durationMinutes,
      );
    } catch (e) {
      times = <String>[];
      errorMessage = _cleanErrorMessage(e);
    } finally {
      isLoading = false;
      if (!_disposed) notifyListeners();
    }
  }

  void _subscribeToAppointmentChanges() {
    final date = _dateString(bookingDate);
    _realtimeChannel = _supabase.channel('urgent_slots_${shopId}_${staffId}_$date')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'appointments',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'staff_id',
          value: staffId,
        ),
        callback: (_) {
          // Recalculate from the same database availability engine.
          // This removes newly booked/conflicting slots immediately.
          loadTimes();
        },
      )
      ..subscribe();
  }

  void selectTime(String time) {
    if (!times.contains(time)) return;
    selectedTime = time;
    notifyListeners();
  }

  String displayTime(String value) {
    final parts = value.split(':');
    if (parts.length < 2) return value;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null) return value;
    final isPm = hour >= 12;
    final displayHour = hour % 12 == 0 ? 12 : hour % 12;
    return '$displayHour:${minute.toString().padLeft(2, '0')} ${isPm ? 'PM' : 'AM'}';
  }

  String _dateString(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _cleanErrorMessage(Object error) {
    final message = error.toString();
    return message.startsWith('Exception: ')
        ? message.substring('Exception: '.length)
        : message;
  }

  @override
  void dispose() {
    _disposed = true;
    _realtimeChannel?.unsubscribe();
    super.dispose();
  }
}
